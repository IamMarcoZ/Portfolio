package it.epicode.epicEnergy.errors;
/**
 * Classe per la entity not found exception
 * @author Marco Cicerano
 * 
 */
public class EntityNotFoundException extends Exception{

	public EntityNotFoundException(String message) {
		super(message);
	}

}
