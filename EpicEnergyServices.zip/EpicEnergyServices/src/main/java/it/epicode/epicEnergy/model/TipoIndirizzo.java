package it.epicode.epicEnergy.model;
/**
 * Enum per il tipo di indirizzo
 * @author Marco Cicerano
 * 
 */
public enum TipoIndirizzo {
	SEDE_LEGALE,SEDE_OPERATIVA;
}
