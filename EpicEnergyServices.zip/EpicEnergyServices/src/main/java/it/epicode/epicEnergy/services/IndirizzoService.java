package it.epicode.epicEnergy.services;
/**
 * Classe service dell'Entity Indirizzo
 * @author MarcoCicerano
 * 
 */
import javax.persistence.EntityNotFoundException;

import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.epicEnergy.dto.indirizzo.IndirizzoDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.model.Comune;
import it.epicode.epicEnergy.model.Indirizzo;
import it.epicode.epicEnergy.repository.ComuneRepository;
import it.epicode.epicEnergy.repository.IndirizzoRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@Service
@Data
@AllArgsConstructor
public class IndirizzoService {
	/**
	 * SingleTon delle repository istanziate con autowired su costruttore
	 * 
	 */
	private ComuneRepository cr;
	private IndirizzoRepository ir;

	/**
	 *  Metodo di inserimento
	 * @param dto
	 * @throws AlreadyPresentException
	 */
	public void insert(IndirizzoDTO dto) throws AlreadyPresentException {
		if(ir.existsByCapAndCivicoAndViaAllIgnoreCase(dto.getCap(), dto.getCivico(), dto.getVia())) {
			throw new AlreadyPresentException("Indirizzo già presente nel db");
		}
		Indirizzo i = new Indirizzo();
		Comune c = cr.findById(dto.getIdComune()).get();
		BeanUtils.copyProperties(dto, i);
		i.setComune(c);
		ir.save(i);
	}
	/**
	 * Metodo di cancellazione
	 * @param id
	 */
	public void delete(Integer id) {
		if(!ir.existsById(id)) {
			throw new EntityNotFoundException("L'indirizzo che vuoi cancellare non è presente nel db");
		}
		ir.deleteById(id);
	}
	/**
	 * Metodo modifica
	 * @param dto
	 * @param id
	 */
	public void update(IndirizzoDTO dto,Integer id) {
		if(!ir.existsById(id)) {
			throw new EntityNotFoundException("L'indirizzo che vuoi modificare non è presente nel db");
		}
		Indirizzo i = ir.findById(id).get();
		Comune c = cr.findById(dto.getIdComune()).get();
		BeanUtils.copyProperties(dto, i);
		i.setComune(c);
		ir.save(i);
	}
	public Page getAllPaged(Pageable page) {
		return ir.findAll(page);
	}
}
