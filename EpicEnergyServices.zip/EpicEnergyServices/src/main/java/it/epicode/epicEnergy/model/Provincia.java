package it.epicode.epicEnergy.model;
/**
 * Entity Provincia,per la creazione della sua tabella su db.
 * @author Marco Cicerano
 * 
 */
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.hibernate.validator.constraints.Length;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Provincia {

	@Id
	private String sigla;
	@Column(nullable = false)
	@Length(min = 2,max = 40)
	private String nomeProvincia;
	@Column(nullable = false)
	@Length(min = 4,max = 40)
	private String regione;
	@OneToMany(mappedBy = "provincia",cascade = CascadeType.REMOVE)
	@JsonIgnore
	private List<Comune> comuni = new ArrayList<>() ; 
}
