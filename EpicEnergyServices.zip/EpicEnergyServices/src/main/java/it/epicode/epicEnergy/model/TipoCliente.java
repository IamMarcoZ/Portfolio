package it.epicode.epicEnergy.model;

/**
 * Enum per il tipo cliente
 * @author Marco Cicerano
 * 
 */
public enum TipoCliente {
	
	PA,SAS,SPA,SRL;
}
