package it.epicode.epicEnergy.model;

/**
 * Entity Cliente,per la creazione della sua tabella su db.
 * @author Marco Cicerano
 * 
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.hibernate.validator.constraints.Length;
import org.springframework.lang.Nullable;

import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@NoArgsConstructor
public class Cliente {

	

	@Id
	private String partitaIva;
	@Column(nullable = false)
	@Length(min = 4,max = 40)
	private String email;
	@Column(nullable = false)
	private LocalDate dataInserimento;
	@Column(nullable = false)
	private LocalDate dataUltimoContatto;
	@Column(nullable = false)
	private double fatturatoAnnuale;
	@Column(nullable = false)
	@Length(min = 4,max = 40)
	private String pec;
	@Column(nullable = false)
	@Length(min = 4,max = 13)
	private String numTel;
	@Column(nullable = false)
	private String ragioneSociale;
	@Column(nullable = false)
	private String emailContatto;
	@Column(nullable = false)
	@Length(min = 2,max = 30)
	private String nomeContatto;
	@Column(nullable = false)
	@Length(min = 2,max = 30)
	private String cognomeContatto;
	@Column(nullable = false)
	private String numTelContatto;
	@OneToMany(mappedBy = "cliente",cascade = CascadeType.REMOVE)
	private List<Fattura> fatture = new ArrayList<Fattura>();
	@Enumerated(EnumType.STRING)
	private TipoCliente tipo;
	@ManyToMany
	@JoinTable(name="indirizzo_cliente", joinColumns = @JoinColumn(name="id_cliente"), inverseJoinColumns = @JoinColumn(name="id_indirizzo"))
	@JsonIgnore
	private List<Indirizzo> indirizzi = new ArrayList<>() ;
}
