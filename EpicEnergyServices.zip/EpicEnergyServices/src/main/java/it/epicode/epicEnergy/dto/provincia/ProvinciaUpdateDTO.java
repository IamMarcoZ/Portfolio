package it.epicode.epicEnergy.dto.provincia;
import javax.validation.constraints.NotBlank;

/**
 * Classe dto per la provincia in particolare per il metodo update
 * @author Marco Cicerano
 * 
 */
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProvinciaUpdateDTO {

	@NotBlank
	private String nomeProvincia;
	@NotBlank
	private String regione;


}
