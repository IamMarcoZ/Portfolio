package it.epicode.epicEnergy.services;
/**
 * Classe service dell'Entity Provincia
 * @author MarcoCicerano
 * 
 */
import javax.persistence.EntityNotFoundException;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.epicEnergy.dto.provincia.ProvinciaInsertDTO;
import it.epicode.epicEnergy.dto.provincia.ProvinciaUpdateDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.model.Provincia;
import it.epicode.epicEnergy.repository.ProvinciaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Service
public class ProvinciaService {
	/**
	 * SingleTon delle repository istanziate con autowired su costruttore
	 * 
	 */
	private ProvinciaRepository pr;

	/**
	 *  Metodo di inserimento
	 * @param dto
	 * @throws AlreadyPresentException
	 */
	public void insert(ProvinciaInsertDTO dto) throws AlreadyPresentException {
		if(pr.existsByNomeProvinciaAllIgnoreCase(dto.getNomeProvincia())){
			throw new AlreadyPresentException("La provincia è già presente nel db");
		}
		Provincia p = new Provincia();
		p.setSigla(dto.getSigla());
		p.setNomeProvincia(dto.getNomeProvincia());
		p.setRegione(dto.getRegione());
		pr.save(p);
	}
	/**
	 * Metodo di cancellazione
	 * @param sigla
	 */
	public void delete(String sigla) {
		if(!pr.existsById(sigla)) {
			throw new EntityNotFoundException("La provincia che vuoi cancellare non esiste nel db");
		}
		pr.deleteById(sigla);
	}
	/**
	 * Metodo modifica
	 * @param dto
	 * @param sigla
	 * @return Provincia modificata
	 */
	public Provincia update(ProvinciaUpdateDTO dto,String sigla) {
		if(!pr.existsById(sigla)) {
			throw new EntityNotFoundException("La provincia che vuoi modificare non è presente nel db");
		}
		Provincia p = pr.findById(sigla).get();
		p.setNomeProvincia(dto.getNomeProvincia());
		p.setRegione(dto.getRegione());
		return	pr.save(p);
	}
	/**
	 * Metodo per la paginazione
	 * @param page
	 * @return Page
	 */
	public Page getAllPaged(Pageable page) {
		return pr.findAll(page);
	}
}
