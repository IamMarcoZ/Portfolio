package it.epicode.epicEnergy.repository;
/**
 * Interfaccia Repository della classe Indirizzo che estende PagingAndSortingRepository grazie alla quale 
 * implementa i metodi crud e metodi per la paginazione e l'ordinamento
 * @author Marco Cicerano
 * 
 */
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.epicEnergy.model.Indirizzo;

public interface IndirizzoRepository extends PagingAndSortingRepository<Indirizzo, Integer> {

		public boolean existsByCapAndCivicoAndViaAllIgnoreCase(String cap,String civico,String via);
}
