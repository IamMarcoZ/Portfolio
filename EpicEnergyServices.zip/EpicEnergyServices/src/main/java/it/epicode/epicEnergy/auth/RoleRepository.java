package it.epicode.epicEnergy.auth;

import org.springframework.data.repository.CrudRepository;

public interface RoleRepository extends CrudRepository<Role, Long> {
public Role findByRoleName( ERole nomeRuolo);
}
