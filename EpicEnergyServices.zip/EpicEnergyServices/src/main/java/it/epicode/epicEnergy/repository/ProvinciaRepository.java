package it.epicode.epicEnergy.repository;
/**
 * Interfaccia Repository della classe Provincia che estende PagingAndSortingRepository grazie alla quale 
 * implementa i metodi crud e metodi per la paginazione e l'ordinamento
 * @author Marco Cicerano
 * 
 */
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.epicEnergy.model.Provincia;

public interface ProvinciaRepository extends PagingAndSortingRepository<Provincia, String> {

	public boolean existsByNomeProvinciaAllIgnoreCase(String nomeProvincia);
}
