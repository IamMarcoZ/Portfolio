package it.epicode.epicEnergy.repository;
/**
 * Interfaccia Repository della classe Comune che estende PagingAndSortingRepository grazie alla quale 
 * implementa i metodi crud e metodi per la paginazione e l'ordinamento
 * @author Marco Cicerano
 * 
 */
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import it.epicode.epicEnergy.model.Comune;

public interface ComuneRepository extends PagingAndSortingRepository<Comune, Integer> {

	public boolean existsByNomeAllIgnoreCase(String nome);

	public List<Comune> findAllByNome(String nome);

	@Query("Select c from Comune c where c.nome like %:nome%  OR lower(c.nome) like lower(concat('%',:nome,'%'))")
	public List<Comune> filterByNome(@Param(value = "nome") String nome);
}	
