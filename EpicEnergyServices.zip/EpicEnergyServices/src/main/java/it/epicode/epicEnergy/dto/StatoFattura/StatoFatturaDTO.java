package it.epicode.epicEnergy.dto.StatoFattura;
import javax.validation.constraints.NotBlank;

/**
 * Classe dto per lo stato fattura
 * @author Marco Cicerano
 * 
 */
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class StatoFatturaDTO {

	@NotBlank
	private String stato;
	
}
