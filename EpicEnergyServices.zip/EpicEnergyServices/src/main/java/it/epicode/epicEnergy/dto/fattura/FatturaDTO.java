package it.epicode.epicEnergy.dto.fattura;
/**
 * Classe dto per la fattura
 * @author Marco Cicerano
 * 
 */
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class FatturaDTO {

	final static String DATE_PATTERN = "dd/MM/yyyy" ;
	
	@NotNull
	private Integer anno;
	@NotNull
	private BigDecimal importo;
	@Schema(example = "20/01/2020",type = "string")
	@JsonFormat(pattern = DATE_PATTERN)
	private LocalDate data;
	@NotBlank
	private String idCliente;
	@NotNull
	private Integer idStato;

}
