package it.epicode.epicEnergy.model;
/**
 * Entity Indirizzo,per la creazione della sua tabella su db.
 * @author Marco Cicerano
 * 
 */
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.validator.constraints.Length;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Indirizzo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(nullable = false)
	@Length(min = 4,max = 40)
	private String via;
	@Column(nullable = false)
	private String civico;
	@ManyToOne
	@JoinColumn(name = "id_comune")
	private Comune comune;
	@Column(nullable = false)
	@Length(min = 4,max = 6)
	private String cap;
	@Column(nullable = false)
	@Length(min = 2,max = 40)
	private String localita;
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private TipoIndirizzo tipo;
	@ManyToMany
	@JoinTable(name="indirizzo_cliente", joinColumns = @JoinColumn(name="id_indirizzo"), inverseJoinColumns = @JoinColumn(name="id_cliente"))
	private List<Cliente> clienti = new ArrayList<>() ;
}
