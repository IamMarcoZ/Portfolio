package it.epicode.epicEnergy.repository;
/**
 * Interfaccia Repository della classe StatoFattura che estende PagingAndSortingRepository grazie alla quale 
 * implementa i metodi crud e metodi per la paginazione e l'ordinamento
 * @author Marco Cicerano
 * 
 */
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.epicEnergy.model.StatoFattura;

public interface StatoFatturaRepository extends PagingAndSortingRepository<StatoFattura, Integer> {

	public boolean existsByStatoAllIgnoreCase(String stato);
	public StatoFattura findByStatoAllIgnoreCase(String stato);
}
