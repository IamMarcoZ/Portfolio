package it.epicode.epicEnergy.controller;
import javax.validation.Valid;

/**
 * Servizi rest della classe Indirizzo
 * @author Marco Cicerano
 * 
 */
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.epicEnergy.dto.indirizzo.IndirizzoDTO;
import it.epicode.epicEnergy.dto.provincia.ProvinciaUpdateDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.services.IndirizzoService;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
@RestController
@RequestMapping("/indirizzi")
public class IndirizzoController {

	/**
	 * Singleton della classe IndirizzoService istanziato tramite autowired su costruttore
	 */
	private IndirizzoService is;
	/**
	 * 
	 * Metodo di inserimento.
	 * @param dto
	 * 
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "INSERISCI INDIRIZZO",description="Inserisce un indirizzo presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Indirizzo inserito con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PostMapping
	public ResponseEntity insert(@RequestBody @Valid IndirizzoDTO dto) throws AlreadyPresentException {
		is.insert(dto);
		return ResponseEntity.ok("Indirizzo inserito nel db");
	}
	/**
	 * 
	 * Metodo di cancellazione tramite chiave primaria.
	 * 
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "ELIMINA INDIRIZZO",description="Elimina un indirizzo presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Indirizzo eliminato con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@DeleteMapping("/{id}")
	public ResponseEntity delete(@PathVariable @Valid Integer id) {
		is.delete(id);
		return ResponseEntity.ok("Indirizzo cancellato");
	}
	/**
	 * 
	 * Metodo di modifica di un indirizzo,ricerca tramite chiave primaria.
	 * @param dto
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "MODIFICA INDIRIZZO",description="Modifica un indirizzo presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Indirizzo modificato con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PutMapping("/{id}")
	public ResponseEntity update(@RequestBody @Valid IndirizzoDTO dto,@PathVariable @Valid Integer id) {
		is.update(dto, id);
		return ResponseEntity.ok("Indirizzo modificato");
	}
	/**
	 * Visualizza indirizzi con paging e sorting
	 * @param page
	 * @return ResponsEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA INDIRIZZI CON PAGING AND SORTING",description="Visualizza tutti gli indirizzi presenti nel db ")
	@ApiResponse(responseCode = "200" ,description = "Lista di indirizzi stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping
	public ResponseEntity getAllPaged(Pageable page) {
		return ResponseEntity.ok(is.getAllPaged(page));
	}
}
