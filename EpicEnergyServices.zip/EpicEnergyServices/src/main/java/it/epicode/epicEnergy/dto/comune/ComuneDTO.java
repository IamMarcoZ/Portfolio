package it.epicode.epicEnergy.dto.comune;
import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ComuneDTO {

	@NotBlank
	private String cap;
	@NotBlank
	private String nome;
	@NotBlank
	private String idProvincia;
}
