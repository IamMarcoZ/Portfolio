package it.epicode.epicEnergy.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.validation.Valid;

import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.epicEnergy.dto.Cliente.ClienteInsertDTO;
import it.epicode.epicEnergy.dto.Cliente.ClienteUpdateDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.services.ClienteService;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
* Servizi rest relativi alla classe Cliente
* @author MarcoCicerano
* 
*/
@RestController
@RequestMapping("/clienti")
@Data
@AllArgsConstructor
public class ClienteController {

	/**
	 * Singleton della classe ClienteService istanziato tramite autowired su costruttore
	 */
	private ClienteService cls;

	/**
	 * Metodo di inserimento 
	 * @param dto
	 * @return ResponseEntity
	 * @throws AlreadyPresentException
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "INSERISCI CLIENTE",description="Inserisce un cliente nel db con i suoi attributi")
	@ApiResponse(responseCode = "200" ,description = "Cliente inserito con successo nel db")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PostMapping
	public ResponseEntity insert(@RequestBody @Valid ClienteInsertDTO dto) throws AlreadyPresentException {
		cls.insert(dto);
		return ResponseEntity.ok("Cliente inserito nel db");
	}
	/**
	 * Metodo di cancellazione di un cliente tramite chiave primaria
	 * @param partitaIva
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "CANCELLA CLIENTE",description="Elimina un cliente presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Cliente eliminato con successo dal db")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@DeleteMapping("/{partitaIva}")
	public ResponseEntity delete(@PathVariable @Valid String partitaIva) {
		cls.delete(partitaIva);
		return ResponseEntity.ok("Cliente cancellato");
	}
	/**
	 * 
	 * Metodo di modifica di un cliente,ricerca tramite chiave primaria.
	 * @param dto
	 * @param partitaIva
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "MODIFICA CLIENTE",description="Modifica un cliente presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Cliente modificato con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PutMapping("/{partitaIva}")
	public ResponseEntity update(@RequestBody @Valid ClienteUpdateDTO dto,@PathVariable @Valid String partitaIva) {
		cls.update(dto, partitaIva);
		return ResponseEntity.ok("Cliente modificato");
	}
	/**
	 * 
	 * Metodo di visualizzazione dei clienti con paging e sort
	 * @param page
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA CLIENTI CON PAGING AND SORTING",description="Visualizza tutti i clienti presenti nel db ")
	@ApiResponse(responseCode = "200" ,description = "Lista dei clienti stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping
	public ResponseEntity getAllPaged(Pageable page) {
		return ResponseEntity.ok(cls.getAllPaged(page));

	}
	/**
	 * Metodo di stampa dei clienti filtrando i risultati per una parte del nome
	 * @param nomeContatto
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "FILTRO CLIENTI PER NOME O PER UNA PARTE DI ESSO",description="Filtra la lista dei clienti per il nome o per una parte di esso")
	@ApiResponse(responseCode = "200" ,description = "Lista filtrata per nome dei clienti stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-nome-contatto/{nomeContatto}")
	public ResponseEntity filterByNome(@PathVariable @Valid String nomeContatto) {
		return ResponseEntity.ok(cls.filterByName(nomeContatto));
	}
	/**
	 * Metodo di stampa dei clienti filtrando per un range di fatturato annuale
	 * @param minFatturatoAnnuale
	 * @param maxFatturatoAnnuale
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "FILTRO CLIENTI PER FATTURATO O PER UNA PARTE DI ESSO",description="Filtra la lista dei clienti per il fatturato")
	@ApiResponse(responseCode = "200" ,description = "Lista filtrata per fatturato dei clienti stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-fatturato-annuale/{minFatturatoAnnuale}/{maxFatturatoAnnuale}")
	public ResponseEntity filterByFatturato(@PathVariable @Valid double minFatturatoAnnuale, @PathVariable @Valid double maxFatturatoAnnuale) {
		return ResponseEntity.ok(cls.filterByFatturatoAnnuale(minFatturatoAnnuale, maxFatturatoAnnuale));
	}
	/**
	 * Metodo di stampa dei clienti filtrando per la data di inserimento
	 * @param dataInserimento
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "FILTRO CLIENTI PER DATA INSERIMENTO",description="Filtra la lista dei clienti per data di inserimento")
	@ApiResponse(responseCode = "200" ,description = "Lista filtrata per data inserimento dei clienti stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-data-inserimento/{dataInserimento}")
	public ResponseEntity filterByDataInserimento(@PathVariable @Valid String dataInserimento) {
		LocalDate dataInserimentoD = LocalDate.parse(dataInserimento,DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		return ResponseEntity.ok(cls.filterByDataInserimento(dataInserimentoD));
	}
	/**
	 * Metodo di stampa dei clienti filtrando per la data di ultimo contatto
	 * @param dataUltimoContatto
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "FILTRO CLIENTI PER DATA ULTIMO CONTATTO",description="Filtra la lista dei clienti per data ultimo contatto")
	@ApiResponse(responseCode = "200" ,description = "Lista filtrata per data ultimo contatto dei clienti stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-data-ultimo-contatto/{dataUltimoContatto}")
	public ResponseEntity filterByDataUltimoContatto(@PathVariable @Valid String dataUltimoContatto) {
		LocalDate dataUltimoContattoD = LocalDate.parse(dataUltimoContatto,DateTimeFormatter.ofPattern("dd-MM-yyyy") );
		return ResponseEntity.ok(cls.filterByDataUltimoContatto(dataUltimoContattoD));
	}
}