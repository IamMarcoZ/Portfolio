package it.epicode.epicEnergy.config;
/**
 * Classe di configurazione dei bean da passare al runner
 * @author Marco Cicerano
 * 
 */
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import it.epicode.epicEnergy.model.Cliente;
import it.epicode.epicEnergy.model.Comune;
import it.epicode.epicEnergy.model.Fattura;
import it.epicode.epicEnergy.model.Indirizzo;
import it.epicode.epicEnergy.model.StatoFattura;
import it.epicode.epicEnergy.model.TipoCliente;
import it.epicode.epicEnergy.model.TipoIndirizzo;
import it.epicode.epicEnergy.repository.ClienteRepository;
import it.epicode.epicEnergy.repository.FatturaRepository;
import it.epicode.epicEnergy.repository.IndirizzoRepository;
import it.epicode.epicEnergy.repository.StatoFatturaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
@Configuration
public class EntityConfig {

	private FatturaRepository fr;
	private StatoFatturaRepository sfr;
	private ClienteRepository cr;
	private IndirizzoRepository ir;
	
	@Primary
	@Bean("indirizzo1")
	public Indirizzo indirizzo() {
		Indirizzo i = new Indirizzo();
		i.setComune(null);
		i.setCivico("12");
		i.setCap("04019");
		i.setLocalita("Terracina");
		i.setTipo(TipoIndirizzo.SEDE_OPERATIVA);
		i.setVia("Via Filippo Brunelleschi");
		return ir.save(i);
	}
		@Bean("indirizzo2")
		public Indirizzo indirizzo2() {
			Indirizzo i = new Indirizzo();
			i.setComune(null);
			i.setCivico("11");
			i.setCap("00125");
			i.setLocalita("Roma");
			i.setTipo(TipoIndirizzo.SEDE_OPERATIVA);
			i.setVia("Via cina");
			return ir.save(i);
	}
	@Primary
	@Bean("cliente1")
	public Cliente cliente() {
		Cliente c = new Cliente();
		List<Indirizzo> indirizzi = new ArrayList<>();
		List<Fattura> fatture = new ArrayList<Fattura>();
		fatture.add(fattura());
		indirizzi.add(indirizzo());
		c.setIndirizzi(indirizzi);
		c.setCognomeContatto("Cicerano");
		c.setEmail("marco.cicerano@hotmail.com");
		c.setEmailContatto("iam_marcoz@hotmail.it");
		c.setFatturatoAnnuale(150000.00);
		c.setNomeContatto("Marco");
		c.setDataInserimento(LocalDate.of(2020, 8, 12));
		c.setDataUltimoContatto(LocalDate.now());
		c.setPartitaIva("12345");
		c.setPec("marco.cicerano@pec.it");
		c.setNumTel("3202587250");
		c.setTipo(TipoCliente.SRL);
		c.setRagioneSociale("Le due sorelle");
		c.setNumTelContatto("3202587250");
		c.setFatture(fatture);
			return	cr.save(c);
	}
	@Bean("cliente2")
	public Cliente cliente2() {
		Cliente c1 = new Cliente();
		List<Indirizzo> indirizzi = new ArrayList<>();
		indirizzi.add(indirizzo());
		c1.setIndirizzi(indirizzi);
		c1.setCognomeContatto("Rossi");
		c1.setEmail("mario.rossi@hotmail.com");
		c1.setEmailContatto("rossi@hotmail.it");
		c1.setDataInserimento(LocalDate.of(2021, 10, 02));
		c1.setDataUltimoContatto(LocalDate.now());
		c1.setFatturatoAnnuale(300000.00);
		c1.setNomeContatto("Mario");
		c1.setPartitaIva("67891AB");
		c1.setPec("mario.rossi@pec.it");
		c1.setNumTel("320231540");
		c1.setTipo(TipoCliente.SPA);
		c1.setRagioneSociale("Bar la seta");
		c1.setNumTelContatto("3204549599");
			return	cr.save(c1);
	
	}

	@Bean("statoFattura")
	public StatoFattura statoFattura() {
		StatoFattura sf = new StatoFattura();
		sf.setStato("pagata");
		sf.setFatture(null);
		return sfr.save(sf);
		
	}
	@Primary
	@Bean("fattura")
	public Fattura fattura() {
		Fattura f = new Fattura();
		f.setNumero(1);
		f.setCliente(cliente2());
		f.setAnno(2022);
		f.setImporto(BigDecimal.valueOf(5000.00));
		f.setStato(statoFattura());
		f.setData(LocalDate.of(2022, 8, 17));
		return fr.save(f);
	}
	@Bean("fattura2")
	public Fattura fattura2() {
		Fattura f = new Fattura();
		f.setNumero(2);
		f.setCliente(cliente2());
		f.setAnno(2022);
		f.setImporto(BigDecimal.valueOf(5000.50));
		f.setStato(statoFattura());
		f.setData(LocalDate.of(2022, 8, 30));
		return fr.save(f);
	}

}
