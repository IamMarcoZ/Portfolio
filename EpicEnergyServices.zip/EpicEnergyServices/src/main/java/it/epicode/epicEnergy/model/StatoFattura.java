package it.epicode.epicEnergy.model;
/**
 * Entity StatoFattura,per la creazione della sua tabella su db.
 * @author Marco Cicerano
 * 
 */
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.validator.constraints.Length;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Data
public class StatoFattura {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(nullable = false)
	@Length(min = 2,max = 40)
	private String stato;
	@OneToMany(mappedBy = "stato",cascade = CascadeType.REMOVE)
	private List<Fattura> fatture;
}
