package it.epicode.epicEnergy.errors;
/**
 * Classe per la gestione centralizzata degli errori in cui passiamo le exception create.
 * @author Marco Cicerano
 * 
 */
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class HandlerException {

	@ExceptionHandler(AlreadyPresentException.class)
	public ResponseEntity entitaGiaEsistenteHandler(AlreadyPresentException e) {
		return new ResponseEntity(e.getMessage(),HttpStatus.BAD_REQUEST);
		
	}


		@ExceptionHandler(EntityNotFoundException.class)
		public ResponseEntity entitaNonEsistenteHandler(EntityNotFoundException e) {
			return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND );
			
		}
	
}
