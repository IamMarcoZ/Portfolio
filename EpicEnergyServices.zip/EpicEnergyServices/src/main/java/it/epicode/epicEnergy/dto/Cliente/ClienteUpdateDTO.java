package it.epicode.epicEnergy.dto.Cliente;
/**
 * Classe dto del Cliente utilizzata in particolare per la modifica
 * @author Marco Cicerano
 * 
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import it.epicode.epicEnergy.model.TipoCliente;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class ClienteUpdateDTO {

	final static String DATE_PATTERN = "dd/MM/yyyy" ;
	
	@NotBlank
	private String email;
	@Schema(example = "20/01/2020")
	@JsonFormat(pattern = DATE_PATTERN)
	private LocalDate dataInserimento;
	@Schema(example = "20/01/2020")
	@JsonFormat(pattern = DATE_PATTERN)
	private LocalDate dataUltimoContatto;
	@NotNull
	private Double fatturatoAnnuale;
	@NotBlank
	private String pec;
	@NotBlank
	private String numTel;
	@NotBlank
	private String emailContatto;
	@NotBlank
	private String nomeContatto;
	@NotBlank
	private String cognomeContatto;
	@NotBlank
	private String numTelContatto;
	private TipoCliente tipo;
	private List<Integer> idIndirizzi= new ArrayList<Integer>();
	@NotBlank
	private String ragioneSociale;
}
