package it.epicode.epicEnergy.csvDto;
/**
 * Classe dto per l'import del file csv
 * @author Marco Cicerano
 * 
 */
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class ProvinceCsvDTO {
	
	
	@JsonProperty("Sigla")
	private String sigla;
	@JsonProperty("Provincia")
	private String nomeProvincia;
	@JsonProperty("Regione")
	private String regione;
}
