package it.epicode.epicEnergy.model;
/**
 * Entity Fattura,per la creazione della sua tabella su db.
 * @author Marco Cicerano
 * 
 */
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.hibernate.annotations.ManyToAny;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Fattura {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer numero;
	@Column(nullable = false)
	private Integer anno;
	@Column(nullable = false)
	private LocalDate data;
	@Column(nullable = false)
	private BigDecimal importo;
	@ManyToOne
	@JoinColumn(name = "id_cliente")
	@JsonIgnore
	private Cliente cliente;
	@ManyToOne
	@JoinColumn( name ="id_stato")
	@JsonIgnore
	private StatoFattura stato;

}
