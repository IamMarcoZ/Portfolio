package it.epicode.epicEnergy.dto.provincia;
import javax.validation.constraints.NotBlank;

/**
 * Classe dto per la provincia in particolare per il metodo insert
 * @author Marco Cicerano
 * 
 */
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProvinciaInsertDTO {
	
	@NotBlank
	private String sigla;
	@NotBlank
	private String nomeProvincia;
	@NotBlank
	private String regione;


}
