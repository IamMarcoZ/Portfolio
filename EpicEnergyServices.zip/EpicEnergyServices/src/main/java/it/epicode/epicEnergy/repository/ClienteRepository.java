package it.epicode.epicEnergy.repository;
/**
 * Interfaccia Repository della classe Cliente che estende PagingAndSortingRepository grazie alla quale 
 * implementa i metodi crud e metodi per la paginazione e l'ordinamento
 * @author Marco Cicerano
 * 
 */
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import it.epicode.epicEnergy.model.Cliente;

public interface ClienteRepository extends PagingAndSortingRepository<Cliente, String>{

	@Query("Select c from Cliente c where c.nomeContatto like %:nomeContatto% OR lower(c.nomeContatto) like lower(concat('%',:nomeContatto,'%'))")
	public List<Cliente> filterByNomeContatto(@Param( value = "nomeContatto") String nomeContatto);
	@Query("Select c from Cliente c where c.dataInserimento = :dataInserimento")
	public List<Cliente> filterByDataInserimento(@Param(value = "dataInserimento") LocalDate dataInserimento);
	@Query("Select c from Cliente c where c.dataUltimoContatto = :dataUltimoContatto ")
	public List<Cliente> filterByDataUltimoContatto(@Param(value = "dataUltimoContatto") LocalDate dataUltimoContatto);
	@Query("Select c from Cliente c where c.fatturatoAnnuale between :minFatturatoAnnuale and :maxFatturatoAnnuale")
	public List<Cliente> filterByFatturato(@Param(value = "minFatturatoAnnuale") double minFatturatoAnnuale,@Param(value = "maxFatturatoAnnuale" ) double maxFatturatoAnnuale);
}
