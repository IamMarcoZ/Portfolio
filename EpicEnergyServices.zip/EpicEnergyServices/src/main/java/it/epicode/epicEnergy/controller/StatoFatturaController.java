package it.epicode.epicEnergy.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.epicEnergy.dto.StatoFattura.StatoFatturaDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.services.StatoFatturaService;
import lombok.AllArgsConstructor;
import lombok.Data;
/**
 * Servizi rest della classe StatoFattura
 * @author MarcoCicerano
 * 
 */
@RestController
@Data
@AllArgsConstructor
@RequestMapping("/stato-fatture")
public class StatoFatturaController {

	/**
	 * Singleton della classe StatoFatturaService istanziato tramite autowired su costruttore
	 */
	private	StatoFatturaService sts;
	/**
	 * Metodo di inserimento
	 * @param dto
	 * @return ResponseEntity
	 * @throws AlreadyPresentException
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "INSERISCI STATO-FATTURA",description="Inserisce uno stato fattura nel db")
	@ApiResponse(responseCode = "200" ,description = "Stato fattura modificato con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PostMapping
	public ResponseEntity<String> insert(@RequestBody @Valid StatoFatturaDTO dto) throws AlreadyPresentException {
		sts.insert(dto);
		return ResponseEntity.ok("Stato fattura inserito nel db");
	}
	/**
	 * Metodo di eliminazione di uno StatoFattura
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "ELIMINA STATO-FATTURA",description="Elimina uno stato fattura presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Stato fattura modificato con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@DeleteMapping("/{id}")
	public ResponseEntity delete(@PathVariable @Valid Integer id) {
		sts.delete(id);
		return ResponseEntity.ok("Stato fattura cancellato");
	}

	/**
	 * Metodi di modifica
	 * @param dto
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "MODIFICA STATO-FATTURA",description="Modifica uno stato fattura presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Stato fattura modificato con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PutMapping("/{id}")
	public ResponseEntity update(@RequestBody @Valid StatoFatturaDTO dto,@PathVariable @Valid Integer id) {
		sts.update(dto, id);
		return ResponseEntity.ok("Stato fattura modificato");
	}
}
