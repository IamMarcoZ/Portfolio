package it.epicode.epicEnergy.runner;
/**
 * Runner per la creazione dei bean delle Entity configurati nella classe config.
 * @author MarcoCicerano
 * 
 */

import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.epicode.epicEnergy.model.Cliente;
import it.epicode.epicEnergy.model.Fattura;
import it.epicode.epicEnergy.model.Indirizzo;
import it.epicode.epicEnergy.model.StatoFattura;
import it.epicode.epicEnergy.repository.ClienteRepository;
import it.epicode.epicEnergy.repository.FatturaRepository;
import it.epicode.epicEnergy.repository.IndirizzoRepository;
import it.epicode.epicEnergy.repository.StatoFatturaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
@Data
@AllArgsConstructor
public class EntityRunner implements CommandLineRunner {

	@Qualifier("statoFattura")
	StatoFattura sf;
	@Qualifier("fattura")
	Fattura f;
	@Qualifier("fattura2")
	Fattura f2;
	@Qualifier("indirizzo1")
	Indirizzo i;
	@Qualifier("indirizzo2")
	Indirizzo i2;
	@Qualifier("cliente1")
	Cliente cliente;
	@Qualifier("cliente2")
	Cliente cliente1;

	
	private ClienteRepository cr;
	private IndirizzoRepository ir;
	private FatturaRepository fr;
	private StatoFatturaRepository sfr;
	/**
	 * Override del metodo run ottenuto implementando l'interfaccia CommandLineRunner
	 */
	@Override
	public void run(String... args) throws Exception {
		ir.save(i);
		ir.save(i2);
		cr.save(cliente1);
		cr.save(cliente);
		fr.save(f);
		fr.save(f2);
		sfr.save(sf);
	log.info("I bean passati al runner sono stati creati");
	}

}
