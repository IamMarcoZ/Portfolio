package it.epicode.epicEnergy.services;
/**
 * Classe service dell'Entity Comune
 * @author MarcoCicerano
 * 
 */

import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.epicEnergy.dto.comune.ComuneDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.model.Comune;
import it.epicode.epicEnergy.model.Provincia;
import it.epicode.epicEnergy.repository.ComuneRepository;
import it.epicode.epicEnergy.repository.ProvinciaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
@Service
public class ComuneService {
	/**
	 * SingleTon delle repository istanziate con autowired su costruttore
	 * 
	 */
	private ComuneRepository cr;
	private ProvinciaRepository pr;
	/**
	 * 
	 * Metodo di inserimento
	 * @param dto
	 * @throws AlreadyPresentException
	 */
	public void insert(ComuneDTO dto) throws AlreadyPresentException {
		if(cr.existsByNomeAllIgnoreCase(dto.getNome())){
			throw new AlreadyPresentException("Il comune che vuoi inserire è già presente nel db");
		}
		Comune c = new Comune();
		Provincia p = pr.findById(dto.getIdProvincia()).get();
		c.setNome(dto.getNome());
		c.setCap(dto.getCap());
		c.setProvincia(p);
		cr.save(c);
	}
	/**
	 * Metodo di cancellazione
	 * @param id
	 */
	public void delete(Integer id) {
		if(!cr.existsById(id)) {
			throw new EntityNotFoundException("Il comune che vuoi cancellare non esiste nel db");
		}
		cr.deleteById(id);
	}
	/**
	 * Metodo modifica
	 * @param dto
	 * @param id
	 * @return Comune modificato
	 */
	public Comune update(ComuneDTO dto,Integer id) {
		if(!cr.existsById(id)) {
			throw new EntityNotFoundException("Il comune che vuoi modificare non esiste nel db");
		}
		Comune c = cr.findById(id).get();
		Provincia p = pr.findById(dto.getIdProvincia()).get();
		c.setNome(dto.getNome());
		c.setCap(dto.getCap());
		c.setProvincia(p);
		return cr.save(c);
	
	}
	/**
	 * Metodo per la paginazione
	 * @param page
	 * @return Page
	 */
	public Page getAllPaged(Pageable page) {
		return cr.findAll(page);
	}

	/**
	 * Metodo di filtraggio per nome 
	 * @param nome
	 * @return Lista di comuni
	 */
	public List<Comune> filterByNome(String nome){
		return cr.filterByNome(nome);
	}
}
