package it.epicode.epicEnergy.runner;

/**
 * 
 * Classe runner che crea in fase di runtime un amministratore ed un utente con i loro ruoli.
 * @author MarcoCicerano
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import it.epicode.epicEnergy.auth.User;
import it.epicode.epicEnergy.auth.UserRepository;
import lombok.extern.slf4j.Slf4j;
@Component
@Order(1)
@Slf4j
public class UserCreationRunner implements CommandLineRunner{

	/**
	 * Istanza di userRepository
	 */
	@Autowired
	UserRepository ur;
	/**
	 * Bean dell'admin
	 */
	@Autowired
	@Qualifier("admin")
	User a;
	/**
	 * Bean dello user
	 */
	@Autowired
	@Qualifier("user")
	User u;
	
	/**
	 * Override del metodo run ottenuto implementando l'interfaccia CommandLineRunner
	 */
	@Override
	public void run(String... args) throws Exception {

		ur.save(a);
		ur.save(u);
		log.info("User e Admin salvati nel db");
	}

}
