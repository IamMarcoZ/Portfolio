package it.epicode.epicEnergy.dto.indirizzo;
/**
 * Classe dto per l'indirizzo
 * @author Marco Cicerano
 * 
 */

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import it.epicode.epicEnergy.model.TipoIndirizzo;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class IndirizzoDTO {

	@NotBlank
	private String via;
	@NotBlank
	private String civico;
	@NotNull
	private Integer idComune;
	@NotBlank
	private String cap;
	@NotBlank
	private String localita;
	@NotBlank
	private TipoIndirizzo tipo;

}
