package it.epicode.epicEnergy.errors;
/**
 * Classe per l'aldready present exception
 * @author Marco Cicerano
 * 
 */
public class AlreadyPresentException extends Exception{

	public AlreadyPresentException(String message) {
		super(message);
	}

	
	
	
}
