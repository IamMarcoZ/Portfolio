package it.epicode.epicEnergy.controller;

import javax.validation.Valid;

import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.epicEnergy.dto.comune.ComuneDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.services.ComuneService;
import lombok.AllArgsConstructor;
import lombok.Data;
/**
 * Servizi rest della classe Comune
 * @author Marco Cicerano
 * 
 */
@RestController
@RequestMapping("/comuni")
@Data
@AllArgsConstructor
public class ComuneController {

	/**
	 * Singleton della classe ComuneService istanziato tramite autowired su costruttore
	 */
	private ComuneService cs;

	/**
	 * Metodo di inserimento 
	 * @param dto
	 * @return ResponseEntity
	 * @throws AlreadyPresentException
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "INSERISCI COMUNE",description="Inserisce un comune nel db con i suoi attributi")
	@ApiResponse(responseCode = "200" ,description = "Comune inserito con successo nel db")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PostMapping
	public ResponseEntity insert(@RequestBody @Valid ComuneDTO dto) throws AlreadyPresentException {
		cs.insert(dto);
		return ResponseEntity.ok("Comune inserito nel db");
	}
	/**
	 * Metodo di cancellazione di un comune tramite chiave primaria
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "CANCELLA COMUNE",description="Cancella un cliente presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Comune eliminato con successo dal db")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@DeleteMapping("/{id}")
	public ResponseEntity delete(@PathVariable @Valid Integer id) {
		cs.delete(id);
		return ResponseEntity.ok("Comune cancellato");
	}
	/**
	 * 
	 * Metodo di modifica 
	 * @param dto
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "MODIFICA COMUNE",description="Modifica il comune presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Comune modificato con successo nel db")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PutMapping("/{id}")
	public ResponseEntity update(@RequestBody @Valid ComuneDTO dto,@PathVariable @Valid Integer id) {
		cs.update(dto, id);
		return ResponseEntity.ok("Comune modificato");
	}
	/**
	 * Metodo di visualizzazione dei comuni con paging and sorting
	 * @param page
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA COMUNI CON PAGING AND SORTING",description="Visualizza tutti i comuni presenti nel db ")
	@ApiResponse(responseCode = "200" ,description = "Lista dei comuni stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping
	public ResponseEntity getAllPaged(Pageable page) {
		return ResponseEntity.ok(cs.getAllPaged(page));
	}
	
	/**
	 * Metodo di filtraggio tramite parte del nome della lista dei comuni
	 * @param nome
	 * @return
	 */
	@GetMapping("/sort-by-nome/{nome}")
	public ResponseEntity filterByNome(@PathVariable @Valid String nome) {
		
		return ResponseEntity.ok(cs.filterByNome(nome));
	}
}