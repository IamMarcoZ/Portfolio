package it.epicode.epicEnergy.runner;
/**
 * Runner per l'importazione dei file csv
 * @author Marco Cicerano
 * 
 */
import java.io.File;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import org.springframework.beans.BeanUtils;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import it.epicode.epicEnergy.csvDto.ComuniCsvDTO;
import it.epicode.epicEnergy.csvDto.ProvinceCsvDTO;
import it.epicode.epicEnergy.model.Comune;
import it.epicode.epicEnergy.model.Provincia;
import it.epicode.epicEnergy.repository.ComuneRepository;
import it.epicode.epicEnergy.repository.ProvinciaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Component
public class CsvRunner implements CommandLineRunner{
	
	private ComuneRepository cr;

	private	ProvinciaRepository pr; 
	/**
	 * Override del metodo run ottenuto implementando l'interfaccia CommandLineRunner
	 */
		@Override
		public void run(String... args) throws Exception {
			
			
			String fileProvinceCsv = "csv/province-italiane.csv";
			CsvSchema provinceCsvSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
			CsvMapper mapper2 = new CsvMapper();
			File fileProvince =new ClassPathResource(fileProvinceCsv).getFile();
			MappingIterator<List<String>> valueReader2 = mapper2 
			.reader(ProvinceCsvDTO.class)
					.with(provinceCsvSchema)
					.readValues(fileProvince);
			for(Object o2 :valueReader2.readAll()) {
				Provincia provincia = new Provincia();
				ProvinceCsvDTO provinceCsv = (ProvinceCsvDTO)o2;
				provincia.setSigla(provinceCsv.getSigla());
				provincia.setRegione(provinceCsv.getRegione());
				provincia.setNomeProvincia(provinceCsv.getNomeProvincia());
				pr.save(provincia);
			
				}
			
			
			String fileComuniCsv = "csv/comuni.csv";
			CsvSchema comuniCsvSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
			CsvMapper mapper = new CsvMapper();
			File fileComuni = new ClassPathResource(fileComuniCsv).getFile();
			MappingIterator<List<String>> valueReader = mapper
					.reader(ComuniCsvDTO.class)
					.with(comuniCsvSchema)
					.readValues(fileComuni);
			for(Object o : valueReader.readAll()) {
				Comune comune = new Comune();
				ComuniCsvDTO comuneCsv = (ComuniCsvDTO)o;
				Optional<Provincia> p = pr.findById(comuneCsv.getProvincia());
				if(p.isPresent()) {
				BeanUtils.copyProperties(o, comune);
				comune.setProvincia(p.get());}
				if(comune.getCap() != null) {
				cr.save(comune);}
			}
			
			
		}
	
	}
