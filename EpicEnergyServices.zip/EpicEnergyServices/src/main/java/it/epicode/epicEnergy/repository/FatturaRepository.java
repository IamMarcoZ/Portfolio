package it.epicode.epicEnergy.repository;
/**
 * Interfaccia Repository della classe Fatura che estende PagingAndSortingRepository grazie alla quale 
 * implementa i metodi crud e metodi per la paginazione e l'ordinamento
 * @author Marco Cicerano
 * 
 */
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import it.epicode.epicEnergy.model.Cliente;
import it.epicode.epicEnergy.model.Fattura;
import it.epicode.epicEnergy.model.StatoFattura;

public interface FatturaRepository extends PagingAndSortingRepository<Fattura, Integer > {

	@Query("Select f from Fattura f JOIN f.cliente c WHERE c.partitaIva =:partitaIva")
	public List<Fattura> filterByCliente(@Param(value = "partitaIva") String partitaIva);
	@Query("Select f from Fattura f JOIN f.stato s WHERE s.stato=:stato")
	public List<Fattura> filterByStato(@Param(value = "stato") String stato);
	@Query("Select f from Fattura f where f.anno between :minAnno and :maxAnno")
	public List<Fattura> filterByRangeAnno(@Param(value = "minAnno")Integer minAnno,@Param(value = "maxAnno")Integer maxAnno);
	@Query("Select f from Fattura f where f.data =:data")
	public List<Fattura> filterByData(@Param(value = "data")LocalDate data);
	@Query("Select f from Fattura f where f.anno =:anno")
	public List<Fattura> filterByAnno(@Param(value = "anno")Integer anno);
	@Query("Select f from Fattura f where f.importo between :minImporto and :maxImporto")
	public List<Fattura> filterByImporti(@Param(value = "minImporto")BigDecimal minImporto,@Param(value = "maxImporto") BigDecimal maxImporto);
	
}
