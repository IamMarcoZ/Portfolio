package it.epicode.epicEnergy.services;
/**
 * Classe service dell'Entity Fattura
 * @author MarcoCicerano
 * 
 */
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.epicEnergy.dto.fattura.FatturaDTO;
import it.epicode.epicEnergy.model.Cliente;
import it.epicode.epicEnergy.model.Fattura;
import it.epicode.epicEnergy.model.StatoFattura;
import it.epicode.epicEnergy.repository.ClienteRepository;
import it.epicode.epicEnergy.repository.FatturaRepository;
import it.epicode.epicEnergy.repository.StatoFatturaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@Service
@Data
@AllArgsConstructor
public class FatturaService {
	/**
	 * SingleTon delle repository istanziate con autowired su costruttore
	 * 
	 */
	FatturaRepository fr;
	ClienteRepository cr;
	StatoFatturaRepository sfr;
	
	/**
	 *  Metodo di inserimento
	 * @param dto
	 * @throws EntityNotFoundException
	 */
	public void insert(FatturaDTO dto) throws EntityNotFoundException {
		if(!cr.existsById(dto.getIdCliente())||!sfr.existsById(dto.getIdStato())) {
			throw new EntityNotFoundException("La fattura ha bisogno di un cliente ed uno stato per essere emessa");
		}
		
		Fattura f = new Fattura();
		Cliente c = cr.findById(dto.getIdCliente()).get();
		StatoFattura sf = sfr.findById(dto.getIdStato()).get();
		BeanUtils.copyProperties(dto, f);
		f.setStato(sf);
		f.setCliente(c);
		fr.save(f);
		
	}
	/**
	 * Metodo di cancellazione
	 * @param numero
	 */
	public void delete(Integer numero) {
		if(!fr.existsById(numero)) {
			throw new EntityNotFoundException("La fattura che vuoi eliminare non è presente nel db");
		}
		fr.deleteById(numero);
	}
	/**
	 * Metodo modifica
	 * @param dto
	 * @param numero
	 */
	public void update(FatturaDTO dto,Integer numero) {
		if(!fr.existsById(numero) ) {
			throw new EntityNotFoundException("La fattura che vuoi modificare non è presente nel db");
		}
		Fattura f = fr.findById(numero).get();
		Cliente c = cr.findById(dto.getIdCliente()).get();
		StatoFattura sf = sfr.findById(dto.getIdStato()).get();
		BeanUtils.copyProperties(dto, f);
		f.setStato(sf);
		f.setCliente(c);
		fr.save(f);
	}
	/**
	 * Metodo per la paginazione
	 * @param page
	 * @return	Page
	 */
	public Page getAllPaged(Pageable page) {
		return fr.findAll(page);
	}
	/**
	 * Metodo di filtraggio per lo stato della fattura
	 * @param stato
	 * @return Lista di fatture
	 */
	public List<Fattura> filterByStato(String stato){
		return fr.filterByStato(stato);
	}
	/**
	 * Metodo di filtraggio per un preciso anno
	 * @param anno
	 * @return Lista di fatture
	 */
	public List<Fattura> filterByAnno(Integer anno){
		return fr.filterByAnno(anno);	
	}
	/**
	 * Metodo di filtraggio per la data della fattura
	 * @param data
	 * @return Lista di fatture
	 */
	public List<Fattura> filterByData(LocalDate data){
		return fr.filterByData(data);
	}
	/**
	 * Metodo di filtraggio per un range di anni
	 * @param minAnno
	 * @param maxAnno
	 * @return Lista di fatture
	 */
	public List<Fattura> filterByRangeAnno(Integer minAnno,Integer maxAnno ){
		return fr.filterByRangeAnno(minAnno, maxAnno);
	}
	/**
	 * Metodo di filtraggio per un range di importi delle fatture
	 * @param minImporto
	 * @param maxImporto
	 * @return Lista di fatture
	 */
	public List<Fattura> filterByRangeImporti(BigDecimal minImporto,BigDecimal maxImporto){
		return fr.filterByImporti(minImporto, maxImporto);
	}
	/**
	 * Metodo di filtraggio per cliente associato alla fattura
	 * @param partitaIva
	 * @return Lista di fatture
	 */
	public List<Fattura> filterByCliente(String partitaIva){
		return fr.filterByCliente(partitaIva);	
	}
	
}
