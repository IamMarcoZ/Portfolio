package it.epicode.epicEnergy.controller;
import javax.validation.Valid;

/**
 * Servizi rest della classe Provincia
 * @author Marco Cicerano
 * 
 */
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.epicEnergy.dto.provincia.ProvinciaInsertDTO;
import it.epicode.epicEnergy.dto.provincia.ProvinciaUpdateDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.services.ProvinciaService;
import lombok.AllArgsConstructor;
import lombok.Data;
@RestController
@AllArgsConstructor
@Data
@RequestMapping("/province")
public class ProvinciaController {

	/**
	 * Singleton della classe ProvinciaService istanziato tramite autowired su costruttore
	 */
	private ProvinciaService ps;
	
	/**
	 * Metodo di inserimento
	 * @param dto
	 * @return ResponseEntity
	 * @throws AlreadyPresentException
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "INSERISCI PROVINCIA",description="Inserisce una provincia nel db")
	@ApiResponse(responseCode = "200" ,description = "Provincia inserita con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PostMapping
	public ResponseEntity insert(@RequestBody @Valid ProvinciaInsertDTO dto) throws AlreadyPresentException {
		ps.insert(dto);
		return ResponseEntity.ok("Provincia inserita nel db");
	}
	/**
	 * Metodo di eliminazione tramite chiave primaria
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "ELIMINA PROVINCIA",description="Elimina una provincia presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Provincia eliminata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@DeleteMapping("/{id}")
	public ResponseEntity delete(@PathVariable @Valid String id) {
		ps.delete(id);
		return ResponseEntity.ok("Provincia cancellata");
	}
	/**
	 * Modifica una provincia
	 * @param dto
	 * @param id
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "MODIFICA PROVINCIA",description="Modifica una provincia presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Provincia modificata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PutMapping("/{id}")
	public ResponseEntity update(@RequestBody @Valid ProvinciaUpdateDTO dto,@PathVariable @Valid String id) {
		ps.update(dto, id);
		return ResponseEntity.ok("Provincia modificata");
	}
	/**
	 * Metodo di visualizzazione di tutte le province con paging e sorting.
	 * @param page
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA PROVINCE CON PAGING AND SORTING",description="Visualizza tutte le province presenti nel db ")
	@ApiResponse(responseCode = "200" ,description = "Lista di province stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping
	public ResponseEntity getAllPaged(Pageable page) {
		return ResponseEntity.ok(ps.getAllPaged(page));
	}
}


