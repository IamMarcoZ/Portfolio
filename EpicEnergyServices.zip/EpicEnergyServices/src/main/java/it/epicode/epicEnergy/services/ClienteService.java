package it.epicode.epicEnergy.services;
/**
 * Classe service dell'Entity del Cliente
 * @author MarcoCicerano
 * 
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.epicEnergy.dto.Cliente.ClienteInsertDTO;
import it.epicode.epicEnergy.dto.Cliente.ClienteUpdateDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.model.Cliente;
import it.epicode.epicEnergy.model.Indirizzo;
import it.epicode.epicEnergy.repository.ClienteRepository;
import it.epicode.epicEnergy.repository.IndirizzoRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Service
public class ClienteService {

	/**
	 * SingleTon delle repository istanziate con autowired su costruttore
	 * 
	 */
	private ClienteRepository cr;
	private IndirizzoRepository ir;
	/**
	 * 
	 * Metodo di inserimento
	 * @param dto
	 * @throws AlreadyPresentException
	 */
	public void insert(ClienteInsertDTO dto) throws AlreadyPresentException {
		if(cr.existsById(dto.getPartitaIva())) {
			throw new AlreadyPresentException("Il cliente che vuoi inserire è già presente nel db");
		}
		Cliente c = new Cliente();

		List<Indirizzo> nuovaListaIndirizzi = new ArrayList<>();
		for(Integer idIndirizzi : dto.getIdIndirizzi()) {
			Indirizzo indirizzo = ir.findById(idIndirizzi).get();
			nuovaListaIndirizzi.add(indirizzo);
			indirizzo.getClienti().add(c);

		}
		BeanUtils.copyProperties(dto, c);
		c.setIndirizzi(nuovaListaIndirizzi);
		cr.save(c);
	}
	/**
	 * Metodo di cancellazione
	 * @param partitaIva
	 */
	public void delete(String partitaIva) {
		if(!cr.existsById(partitaIva)) {
			throw new EntityNotFoundException("Il cliente che vuoi cancellare non è presente nel db");
		}
		cr.deleteById(partitaIva);
	}
	/**
	 * Metodo modifica
	 * @param dto
	 * @param partitaIva
	 */
	public void update(ClienteUpdateDTO dto,String partitaIva) {
		if(!cr.existsById(partitaIva)) {
			throw new EntityNotFoundException("Il cliente che vuoi modificare non è presente nel db");
		}
		Cliente c = cr.findById(partitaIva).get();

		List<Indirizzo> nuovaListaIndirizzi = new ArrayList<>();
		for(Integer idIndirizzi : dto.getIdIndirizzi()) {
			Indirizzo indirizzo = ir.findById(idIndirizzi).get();
			nuovaListaIndirizzi.add(indirizzo);
			indirizzo.getClienti().add(c);

		}
		
		BeanUtils.copyProperties(dto, c);
		c.setIndirizzi(nuovaListaIndirizzi);
		c.setPartitaIva(partitaIva);
		cr.save(c);
	}
	/**
	 * Metodo per la paginazione
	 * @param page
	 * @return Page
	 */
	public Page getAllPaged(Pageable page) {
		return cr.findAll(page);
	}
	/**
	 * Metodo di filtaggio per nome
	 * @param nomeContatto
	 * @return Lista di clienti 
	 */
	public List<Cliente> filterByName(String nomeContatto){
		return cr.filterByNomeContatto(nomeContatto);
	}
	/**
	 * Metodo di filtraggio per un range di fatturato annuale
	 * @param minFatturatoAnnuale
	 * @param maxFatturatoAnnuale
	 * @return Lista di clienti
	 */
	public List<Cliente> filterByFatturatoAnnuale(double minFatturatoAnnuale,double maxFatturatoAnnuale){
		return cr.filterByFatturato(minFatturatoAnnuale, maxFatturatoAnnuale);
	}
	/**
	 * Metodo di filtraggio per la data di inserimento
	 * @param dataInserimento
	 * @return	Lista di clienti
	 */
	public List<Cliente> filterByDataInserimento(LocalDate dataInserimento){
		return cr.filterByDataInserimento(dataInserimento);
	}
	/**
	 * Metodo di filtraggio per la data di ultimo contatto
	 * @param dataUltimoContatto
	 * @return Lista di clienti
	 */
	public List<Cliente> filterByDataUltimoContatto(LocalDate dataUltimoContatto){
		return cr.filterByDataUltimoContatto(dataUltimoContatto);
	}
	
	}
