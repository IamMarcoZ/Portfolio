package it.epicode.epicEnergy.controller;
/**
 * 
 * Servizi rest della classe Fattura
 * @author Marco Cicerano
 * 
 */
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.epicEnergy.dto.fattura.FatturaDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.services.FatturaService;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
@RestController
@RequestMapping("/fatture")
public class FatturaController {
	
	/**
	 * Singleton della classe FatturaService istanziamo tramite autowired su costruttore
	 * 
	 */
	private FatturaService fs;
	  
	/**
	 * Metodo di inserimento
	 * @param dto
	 * @return ResponseEntity
	 * @throws EntityNotFoundException
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "INSERISCI FATTURA",description="Inserisce una fattura nel db con i suoi attributi")
	@ApiResponse(responseCode = "200" ,description = "Fattura inserita con successo nel db")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PostMapping
	public ResponseEntity insert(@RequestBody @Valid FatturaDTO dto) throws EntityNotFoundException {
		fs.insert(dto);
		return ResponseEntity.ok("Fattura inserito nel db");
	}
	/**
	 * Metodo di cancellazione tramite chiave primaria
	 * @param numero
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "ELIMINA FATTURA",description="Elimina una fattura presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Fattura eliminata con succecsso")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@DeleteMapping("/{numero}")
	public ResponseEntity delete(@PathVariable @Valid Integer numero) {
		fs.delete(numero);
		return ResponseEntity.ok("Fattura cancellata");
	}
	/**
	 * Metodo modifica
	 * @param dto
	 * @param numero
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@Operation(summary= "MODIFICA FATTURA",description="Modifica una fattura presente nel db")
	@ApiResponse(responseCode = "200" ,description = "Fattura modificata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@PutMapping("/{numero}")
	public ResponseEntity update(@RequestBody @Valid FatturaDTO dto,@PathVariable @Valid Integer numero) {
		fs.update(dto, numero);
		return ResponseEntity.ok("Fattura modificata");
	}
	/**
	 * Metodo di visualizzazione delle fatture con paging and sorting
	 * @param page
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA FATTURE CON PAGING AND SORTING",description="Visualizza tutte le fatture presenti nel db ")
	@ApiResponse(responseCode = "200" ,description = "Lista delle fatture stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping
	public ResponseEntity getAllPaged(Pageable page) {
		return ResponseEntity.ok(fs.getAllPaged(page));
	}
	/**
	 * Metodo di visualizzazione di una lista di fatture filtrata per cliente
	 * @param partitaIva
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA LE FATTURE DI UN DATO CLIENTE",description="Visualizza tutte le fatture presenti nel db di un cliente data la sua partita iva")
	@ApiResponse(responseCode = "200" ,description = "Lista delle fatture stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-cliente/{partitaIva}")
	public ResponseEntity filterByCliente(@PathVariable @Valid String partitaIva) {
		String partitaIvaString ;
		
		return ResponseEntity.ok(fs.filterByCliente(partitaIva));
	}
	/**
	 * Metodo di filtraggio di una lista di fatture filtrate per stato
	 * @param stato
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA FATTURE FILTRANDO PER IL LORO STATO",description="Visualizza tutte le fatture presenti nel db con un dato stato")
	@ApiResponse(responseCode = "200" ,description = "Lista delle fatture stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-stato/{stato}")
	public ResponseEntity filterByStato(@PathVariable @Valid String stato) {
		return ResponseEntity.ok(fs.filterByStato(stato));
	}
	/**
	 * Metodo di filtraggio di una lista di fatture filtrate per un range di anni 
	 * @param minAnno
	 * @param maxAnno
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA FATTURE COMPRESE TRA IL RANGE DI ANNI MESSI IN INPUT",description="Visualizza tutte le fatture presenti nel db in un dato range di anni")
	@ApiResponse(responseCode = "200" ,description = "Lista delle fatture stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-range-anno/{minAnno}/{maxAnno}")
	public ResponseEntity filterByRangeAnno(@PathVariable @Valid Integer minAnno, @PathVariable @Valid Integer maxAnno) {
		return ResponseEntity.ok(fs.filterByRangeAnno(minAnno, maxAnno));
	}
	/**
	 * Metodo di filtraggio di una lista di fatture filtrate per una data precisa
	 * @param data
	 * @return
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA FATTURE FILTRATE PER UNA DATA",description="Visualizza tutte le fatture presenti nel db con una data precisa")
	@ApiResponse(responseCode = "200" ,description = "Lista delle fatture stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-data/{data}")
	public ResponseEntity filterByData(@PathVariable @Valid String data) {
		LocalDate dataD = LocalDate.parse(data,DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		return ResponseEntity.ok(fs.filterByData(dataD));
	}
	/**
	 * Metodo di filtraggio di una lista di fatture filtrate per un anno preciso
	 * @param anno
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA FATTURE DI UN DETERMINATO ANNO",description="Visualizza tutte le fatture presenti nel db di un dato anno")
	@ApiResponse(responseCode = "200" ,description = "Lista delle fatture stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-anno/{anno}")
	public ResponseEntity filterByAnno(@PathVariable @Valid Integer anno) {
		return ResponseEntity.ok(fs.filterByAnno(anno));
	}
	/**
	 * Metodo di filtraggio di una lista di fatture filtrate per un range di importi
	 * @param minImporto
	 * @param maxImporto
	 * @return ResponseEntity
	 */
	@SecurityRequirement(name= "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@Operation(summary= "VISUALIZZA FATTURE COMPRESE TRA IL RANGE DI IMPORTI MESSI IN INPUT ",description="Visualizza tutte le fatture presenti nel db in un dato range di importi")
	@ApiResponse(responseCode = "200" ,description = "Lista delle fatture stampata con successo")
	@ApiResponse(responseCode = "500" , description = "Errore nel server")
	@GetMapping("/filter-by-importi/{minImporto}/{maxImporto}")
	public ResponseEntity filterByImporti(@PathVariable @Valid BigDecimal minImporto,@PathVariable @Valid BigDecimal maxImporto) {
		return ResponseEntity.ok(fs.filterByRangeImporti(minImporto, maxImporto));
	}
}
