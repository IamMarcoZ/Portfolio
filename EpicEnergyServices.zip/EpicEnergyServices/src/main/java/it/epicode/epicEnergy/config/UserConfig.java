package it.epicode.epicEnergy.config;
/**
 * Classe di configurazione dei bean admin e user da passare al runner .
 * @author MarcoCicerano
 * 
 */

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import it.epicode.epicEnergy.auth.ERole;
import it.epicode.epicEnergy.auth.Role;
import it.epicode.epicEnergy.auth.User;
import it.epicode.epicEnergy.auth.UserRepository;



@Configuration
public class UserConfig {
	@Autowired
	PasswordEncoder pe;
	@Autowired
	UserRepository ur;
	
	@Bean("admin")
	public User userAdmin() {
		Role admin = new Role();
		admin.setRoleName(ERole.ROLE_ADMIN);
		User userAdmin = new User();
		Set<Role> ruoli = new HashSet<Role>();
		ruoli.add(admin);
		userAdmin.setRoles(ruoli);
		userAdmin.setUsername("admin");
		userAdmin.setPassword(pe.encode("admin"));
		userAdmin.setNome("Marco");
		userAdmin.setCognome("Cicerano");
		userAdmin.setEmail("marco.cicerano@hotmail.com");
		return userAdmin;
	}
	@Bean("user")
	public User user() {
		Role user = new Role();
		user.setRoleName(ERole.ROLE_USER);
		User userRestricted = new User();
		Set<Role> ruoli = new HashSet<Role>();
		ruoli.add(user);
		userRestricted.setRoles(ruoli);
		userRestricted.setUsername("user");
		userRestricted.setPassword(pe.encode("user"));
		userRestricted.setNome("Mario");
		userRestricted.setCognome("Rossi");
		userRestricted.setEmail("mario.rossi@gmail.com");
		return userRestricted;
		
	}
}