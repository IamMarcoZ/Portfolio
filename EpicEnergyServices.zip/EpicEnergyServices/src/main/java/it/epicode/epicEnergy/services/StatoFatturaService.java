package it.epicode.epicEnergy.services;
/**
 * Classe service dell'Entity StatoFattura
 * @author MarcoCicerano
 * 
 */
import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import it.epicode.epicEnergy.dto.StatoFattura.StatoFatturaDTO;
import it.epicode.epicEnergy.errors.AlreadyPresentException;
import it.epicode.epicEnergy.model.StatoFattura;
import it.epicode.epicEnergy.repository.StatoFatturaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
@Service
public class StatoFatturaService {
	/**
	 * SingleTon delle repository istanziate con autowired su costruttore
	 * 
	 */
	private StatoFatturaRepository sfr;
	
	/**
	 *  Metodo di inserimento
	 * @param dto
	 * @throws AlreadyPresentException
	 */
	public void insert(StatoFatturaDTO dto) throws AlreadyPresentException {
		if(sfr.existsByStatoAllIgnoreCase(dto.getStato())) {
			throw new AlreadyPresentException("Lo stato che vuoi aggiungere al db è già presente");
		}
		StatoFattura statoFattura = new StatoFattura();
		statoFattura.setStato(dto.getStato());
		sfr.save(statoFattura);
	}
	/**
	 * Metodo di cancellazione
	 * @param id
	 */
	public void delete(Integer id) {
		if(!sfr.existsById(id)) {
			throw new EntityNotFoundException("Lo stato che vuoi cancellare non è presente nel db");
		}
		sfr.deleteById(id);
	}
	/**
	 * Metodo modifica
	 * @param dto
	 * @param id
	 * @return Stato Fattura modificato
	 */
	public StatoFattura update(StatoFatturaDTO dto,Integer id) {
		if(!sfr.existsById(id)) {
			 throw new EntityNotFoundException("Lo stato fattura che vuoi modificare non è presente nel db");		}
	
	StatoFattura statoFattura = sfr.findById(id).get();
		statoFattura.setStato(dto.getStato());
		return sfr.save(statoFattura);
	}
	
		
}
