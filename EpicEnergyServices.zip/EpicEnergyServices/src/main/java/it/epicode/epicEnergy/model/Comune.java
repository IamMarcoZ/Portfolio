package it.epicode.epicEnergy.model;
/**
 * Entity Comune,per la creazione della sua tabella su db.
 * @author Marco Cicerano
 * 
 */
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Comune {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(nullable = false)
	private String cap;
	@Column(nullable = false)
	private String nome;
	@OneToMany(mappedBy = "comune")
	private List<Indirizzo> indirizzi = new ArrayList<>();
	@ManyToOne
	@JoinColumn(name="sigla_provincia")
	@JsonIgnore
	private Provincia provincia;
}
