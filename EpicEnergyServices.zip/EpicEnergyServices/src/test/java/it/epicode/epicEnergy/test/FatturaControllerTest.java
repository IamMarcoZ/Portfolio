package it.epicode.epicEnergy.test;
/**
 * Classe di test per i le chiamate del controller della fattura
 * @author Marco Cicerano
 * 
 */
import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.epicEnergy.auth.LoginRequest;
import it.epicode.epicEnergy.dto.fattura.FatturaDTO;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class FatturaControllerTest {

	@Autowired
	private TestRestTemplate restTemplate;
	
	@LocalServerPort
	private int port;

	/**
	 * Metodo per simulare il token dell'amministratore per usarlo nei vari test
	 * @return jwt
	 */
	protected String getAdminToken() {
        String url = "http://localhost:" + port + "/api/auth/login/jwt";
        LoginRequest login = new LoginRequest();
        login.setUserName("admin");
        login.setPassword("admin");
        HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
        String jwt = restTemplate.postForObject(url, loginRequest, String.class);
        log.info("---------" + jwt);
        return jwt;
    }
	/**
	 * Metodo per simulare il token dello user per usarlo nei vari test
	 * @return jwt
	 */
    protected String getUserToken() {
        String url = "http://localhost:" + port + "/api/auth/login/jwt";
        LoginRequest login = new LoginRequest();
        login.setUserName("user");
        login.setPassword("user");
        HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
        String jwt = restTemplate.postForObject(url, loginRequest, String.class);
        return jwt;
    }
    /**
  	 * Metodo per prendere l'header dell' amministratore per usarlo nei vari test
  	 * @return header
  	 */
	protected HttpHeaders getAdminHeader() {
        HttpHeaders header = new HttpHeaders();
        String jwt = getAdminToken();
        header.set("Authorization", "Bearer " + jwt);
        return header;
        
        
    }
	 /**
	   * Metodo per prendere l'header dello user per usarlo nei vari test
	   * @return header
	   */
    protected HttpHeaders getUserHeader() {
        HttpHeaders header = new HttpHeaders();
        String jwt = getUserToken();
        header.set("Authorization", "Bearer " + jwt);
        return header;
        
}
  
    /**
     * 
     * Metodi di test di tutte le chiamate presenti nel controller,il metodo simula l'accesso in tutti i casi,
     * nel caso sia un utente non autenticato,nel caso sia un admin,nel caso sia uno user,per ogni caso 
     * abbiamo l'http status che riceverebbe quell'utente in caso di chiamata al metodo.
     * 
     */
    @Test
    void delete() {
		String url = "http://localhost:" + port + "/fatture/1";
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY,String.class);
		log.info("TEST DELETE" + url + "DELETE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	
		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.DELETE, adminEntity,String.class);
		log.info("TEST DELETE" + url + "DELETE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	
		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = restTemplate.exchange(url, HttpMethod.DELETE, userEntity,String.class);
		log.info("TEST DELETE" + url + "DELETE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
    
	@Test
	void update() {
		String url = "http://localhost:" + port + "/fatture/2";
		FatturaDTO dto = new FatturaDTO();
		dto.setAnno(2020);
    	dto.setData(LocalDate.now());
    	dto.setIdCliente("12345");
    	dto.setIdStato(1);
    	dto.setImporto(BigDecimal.valueOf(5000.50));
		HttpEntity<FatturaDTO> fatturaEntity = new HttpEntity<FatturaDTO>(dto);

		ResponseEntity<String> r = restTemplate.exchange(url,HttpMethod.PUT ,fatturaEntity, String.class);
		log.info("TEST UPDATE " + url + "UPDATE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<FatturaDTO> adminEntity = new HttpEntity<FatturaDTO>(dto,getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.PUT,adminEntity, String.class);
		log.info("TEST UPDATE " + url + "UPDATE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<FatturaDTO> userEntity = new HttpEntity<FatturaDTO>(dto,getUserHeader());
		r = restTemplate.exchange(url,HttpMethod.PUT ,userEntity, String.class);
		log.info("TEST UPDATE " + url + "UPDATE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

	}
	  @Test
	    void insert() {
	    	String url = "http://localhost:" + port + "/fatture";
	    	FatturaDTO dto = new FatturaDTO();
	    	dto.setAnno(2020);
	    	dto.setData(LocalDate.of(1122, 6, 11));
	    	dto.setIdCliente("12345");
	    	dto.setIdStato(1);
	    	dto.setImporto(BigDecimal.valueOf(5000.50));
	    	HttpEntity<FatturaDTO> fatturaEntity = new HttpEntity<FatturaDTO>(dto);
			log.info("TEST INSERT " + url + "POST");
	    	ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.POST , fatturaEntity , String.class);
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	    	
			HttpEntity<FatturaDTO> adminEntity = new HttpEntity<FatturaDTO>(dto,getAdminHeader());
			log.info("TEST INSERT " + url + "POST");
			r= restTemplate.exchange(url, HttpMethod.POST,adminEntity, String.class);
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<FatturaDTO> userEntity = new HttpEntity<FatturaDTO>(dto,getUserHeader());
			log.info("TEST INSERT " + url + "POST");
			r= restTemplate.exchange(url, HttpMethod.POST,userEntity, String.class);
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	    }
	  	@Test
	    void allFatturePaged() {
			String url = "http://localhost:" + port + "/fatture" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	    @Test
	    void filterByCliente() {
			String url = "http://localhost:" + port + "/fatture/filter-by-cliente/67891AB" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	    @Test
	    void filterByStato() {
			String url = "http://localhost:" + port + "/fatture/filter-by-stato/pagata" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	    @Test
	    void filterByRangeAnni() {
			String url = "http://localhost:" + port + "/fatture/filter-by-range-anno/2000/2023" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	    @Test
	    void filterByData() {
			String url = "http://localhost:" + port + "/fatture/filter-by-data/2022-08-17" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
}
	    @Test
	    void filterByAnno() {
			String url = "http://localhost:" + port + "/fatture/filter-by-anno/2022" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
}
	    @Test
	    void filterByImporti() {
			String url = "http://localhost:" + port + "/fatture/filter-by-importi/3000.00/330000.00" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
}
}