package it.epicode.epicEnergy.test;
/**
 * Classe di test per i le chiamate del controller dell'indirizzo
 * @author Marco Cicerano
 * 
 */
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.epicEnergy.auth.LoginRequest;
import it.epicode.epicEnergy.dto.StatoFattura.StatoFatturaDTO;
import it.epicode.epicEnergy.dto.indirizzo.IndirizzoDTO;
import it.epicode.epicEnergy.model.TipoIndirizzo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class IndirizzoControllerTest {
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	@LocalServerPort
	private int port;

	/**
	 * Metodo per simulare il token dell'amministratore per usarlo nei vari test
	 * @return jwt
	 */
	protected String getAdminToken() {
        String url = "http://localhost:" + port + "/api/auth/login/jwt";
        LoginRequest login = new LoginRequest();
        login.setUserName("admin");
        login.setPassword("admin");
        HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
        String jwt = restTemplate.postForObject(url, loginRequest, String.class);
        log.info("---------" + jwt);
        return jwt;
    }
	/**
	 * Metodo per simulare il token dello user per usarlo nei vari test
	 * @return jwt
	 */
    protected String getUserToken() {
        String url = "http://localhost:" + port + "/api/auth/login/jwt";
        LoginRequest login = new LoginRequest();
        login.setUserName("user");
        login.setPassword("user");
        HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
        String jwt = restTemplate.postForObject(url, loginRequest, String.class);
        return jwt;
    }
    /**
  	 * Metodo per prendere l'header dell' amministratore per usarlo nei vari test
  	 * @return header
  	 */
	protected HttpHeaders getAdminHeader() {
        HttpHeaders header = new HttpHeaders();
        String jwt = getAdminToken();
        header.set("Authorization", "Bearer " + jwt);
        return header;
        
        
    }
	 /**
	   * Metodo per prendere l'header dello user per usarlo nei vari test
	   * @return header
	   */
    protected HttpHeaders getUserHeader() {
        HttpHeaders header = new HttpHeaders();
        String jwt = getUserToken();
        header.set("Authorization", "Bearer " + jwt);
        return header;
        
}
    /**
     * 
     * Metodi di test di tutte le chiamate presenti nel controller,il metodo simula l'accesso in tutti i casi,
     * nel caso sia un utente non autenticato,nel caso sia un admin,nel caso sia uno user,per ogni caso 
     * abbiamo l'http status che riceverebbe quell'utente in caso di chiamata al metodo.
     * 
     */
    @Test
    void insert() {
    	String url = "http://localhost:" + port + "/indirizzi";
    	IndirizzoDTO dto = new IndirizzoDTO();
    	dto.setCap("11111");
    	dto.setCivico("181");
    	dto.setLocalita("Mare");
    	dto.setTipo(TipoIndirizzo.SEDE_OPERATIVA);
    	dto.setIdComune(1);
    	dto.setVia("Via Roma");
    	HttpEntity<IndirizzoDTO> statoFatturaEntity = new HttpEntity<IndirizzoDTO>(dto);
		log.info("TEST INSERT " + url + "POST");
    	ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.POST , statoFatturaEntity , String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
    	
		HttpEntity<IndirizzoDTO> adminEntity = new HttpEntity<IndirizzoDTO>(dto,getAdminHeader());
		log.info("TEST INSERT " + url + "POST");
		r= restTemplate.exchange(url, HttpMethod.POST,adminEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	
		HttpEntity<IndirizzoDTO> userEntity = new HttpEntity<IndirizzoDTO>(dto,getUserHeader());
		log.info("TEST INSERT " + url + "POST");
		r= restTemplate.exchange(url, HttpMethod.POST,userEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
    }
    @Test
    void delete() {
		String url = "http://localhost:" + port + "/indirizzi/2";
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY,String.class);
		log.info("TEST DELETE" + url + "DELETE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	
		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.DELETE, adminEntity,String.class);
		log.info("TEST DELETE" + url + "DELETE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	
		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = restTemplate.exchange(url, HttpMethod.DELETE, userEntity,String.class);
		log.info("TEST DELETE" + url + "DELETE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void update() {
		String url = "http://localhost:" + port + "/indirizzi/1";
		IndirizzoDTO dto = new IndirizzoDTO();
		dto.setCap("11111");
    	dto.setCivico("181");
    	dto.setLocalita("Mare");
    	dto.setTipo(TipoIndirizzo.SEDE_OPERATIVA);
    	dto.setIdComune(1);
    	dto.setVia("Via Roma");
		HttpEntity<IndirizzoDTO> indirizzoEntity = new HttpEntity<IndirizzoDTO>(dto);

		ResponseEntity<String> r = restTemplate.exchange(url,HttpMethod.PUT ,indirizzoEntity, String.class);
		log.info("TEST UPDATE " + url + "UPDATE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<IndirizzoDTO> adminEntity = new HttpEntity<IndirizzoDTO>(dto,getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.PUT,adminEntity, String.class);
		log.info("TEST UPDATE " + url + "UPDATE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<IndirizzoDTO> userEntity = new HttpEntity<IndirizzoDTO>(dto,getUserHeader());
		r = restTemplate.exchange(url,HttpMethod.PUT ,userEntity, String.class);
		log.info("TEST UPDATE " + url + "UPDATE");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

	}
	 @Test
	    void allIndirizziPaged() {
			String url = "http://localhost:" + port + "/indirizzi" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
}