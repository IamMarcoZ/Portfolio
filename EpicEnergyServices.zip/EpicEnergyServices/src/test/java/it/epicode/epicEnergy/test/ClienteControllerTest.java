package it.epicode.epicEnergy.test;
/**
 * Classe di test per i le chiamate del controller del cliente
 * @author Marco Cicerano
 * 
 */
import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.epicEnergy.auth.LoginRequest;
import it.epicode.epicEnergy.dto.Cliente.ClienteInsertDTO;
import it.epicode.epicEnergy.dto.Cliente.ClienteUpdateDTO;
import it.epicode.epicEnergy.dto.fattura.FatturaDTO;
import it.epicode.epicEnergy.model.Indirizzo;
import it.epicode.epicEnergy.model.TipoCliente;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ClienteControllerTest {

	@Autowired
	private TestRestTemplate restTemplate;
	@Qualifier("indirizzo")
	Indirizzo i;

	@LocalServerPort
	private int port;
	/**
	 * Metodo per simulare il token dell'amministratore per usarlo nei vari test
	 * @return jwt
	 */
	protected String getAdminToken() {
        String url = "http://localhost:" + port + "/api/auth/login/jwt";
        LoginRequest login = new LoginRequest();
        login.setUserName("admin");
        login.setPassword("admin");
        HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
        String jwt = restTemplate.postForObject(url, loginRequest, String.class);
        log.info("---------" + jwt);
        return jwt;
    }
	/**
	 * Metodo per simulare il token dello user per usarlo nei vari test
	 * @return jwt
	 */
    protected String getUserToken() {
        String url = "http://localhost:" + port + "/api/auth/login/jwt";
        LoginRequest login = new LoginRequest();
        login.setUserName("user");
        login.setPassword("user");
        HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
        String jwt = restTemplate.postForObject(url, loginRequest, String.class);
        return jwt;
    }
    /**
	 * Metodo per prendere l'header dell' amministratore per usarlo nei vari test
	 * @return header
	 */
	protected HttpHeaders getAdminHeader() {
        HttpHeaders header = new HttpHeaders();
        String jwt = getAdminToken();
        header.set("Authorization", "Bearer " + jwt);
        return header;
        }
	  /**
	   * Metodo per prendere l'header dello user per usarlo nei vari test
	   * @return header
	   */
    protected HttpHeaders getUserHeader() {
        HttpHeaders header = new HttpHeaders();
        String jwt = getUserToken();
        header.set("Authorization", "Bearer " + jwt);
        return header;
        
    }
    /**
     * 
     * Metodi di test di tutte le chiamate presenti nel controller,il metodo simula l'accesso in tutti i casi,
     * nel caso sia un utente non autenticato,nel caso sia un admin,nel caso sia uno user,per ogni caso 
     * abbiamo l'http status che riceverebbe quell'utente in caso di chiamata al metodo.
     * 
     */
	  @Test
	    void insert() {
	    	String url = "http://localhost:" + port + "/clienti";
	    	ClienteInsertDTO dto = new ClienteInsertDTO();	    	
	    	List<Integer> idIndirizzi = new ArrayList<Integer>();
	    	idIndirizzi.add(1);
	    	dto.setPartitaIva("223344");
	    	dto.setCognomeContatto("Cicerano");
	    	dto.setDataInserimento(LocalDate.of(2020, 9, 17));
	    	dto.setDataUltimoContatto(LocalDate.now());
	    	dto.setEmail("marco.cicerano@hotmail.com");
	    	dto.setEmailContatto("lalala@gmail.com");
	    	dto.setFatturatoAnnuale(150000.00);
	    	dto.setNomeContatto("Le due torri");
	    	dto.setNumTel("3202587250");
	    	dto.setNumTelContatto("3923526973");
	    	dto.setPec("marco@pec.it");
	    	dto.setRagioneSociale("CiaoCiao");
	    	dto.setTipo(TipoCliente.SRL);
	    	dto.setIdIndirizzi(idIndirizzi);
	    	HttpEntity<ClienteInsertDTO> ClienteEntity = new HttpEntity<ClienteInsertDTO>(dto);
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.POST , ClienteEntity , String.class);
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	    	
			HttpEntity<ClienteInsertDTO> adminEntity = new HttpEntity<ClienteInsertDTO>(dto,getAdminHeader());
			r= restTemplate.exchange(url, HttpMethod.POST,adminEntity, String.class);
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<ClienteInsertDTO> userEntity = new HttpEntity<ClienteInsertDTO>(dto,getUserHeader());
			r= restTemplate.exchange(url, HttpMethod.POST,userEntity, String.class);
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	    }
	  @Test
		void update() {
		  
			String url = "http://localhost:" + port + "/clienti/223344";
			ClienteUpdateDTO dto = new ClienteUpdateDTO();
			List<Integer> idIndirizzi = new ArrayList<Integer>();
	    	idIndirizzi.add(1);
	    	dto.setIdIndirizzi(idIndirizzi);
			dto.setCognomeContatto("Cicerano");
	    	dto.setDataInserimento(LocalDate.of(2020, 9, 17));
	    	dto.setDataUltimoContatto(LocalDate.now());
	    	dto.setEmail("marco.cicerano@hotmail.com");
	    	dto.setEmailContatto("lalala@gmail.com");
	    	dto.setFatturatoAnnuale(150000.00);
	    	dto.setNomeContatto("Le due torri");
	    	dto.setNumTel("3202587250");
	    	dto.setNumTelContatto("3923526973");
	    	dto.setPec("marco@pec.it");
	    	dto.setRagioneSociale("CiaoCiao");
	    	
	    	HttpEntity<ClienteUpdateDTO> fatturaEntity = new HttpEntity<ClienteUpdateDTO>(dto);

			ResponseEntity<String> r = restTemplate.exchange(url,HttpMethod.PUT ,fatturaEntity, String.class);
			log.info("TEST UPDATE " + url + "UPDATE");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
			
			HttpEntity<ClienteUpdateDTO> adminEntity = new HttpEntity<ClienteUpdateDTO>(dto,getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.PUT,adminEntity, String.class);
			log.info("TEST UPDATE " + url + "UPDATE");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

			HttpEntity<ClienteUpdateDTO> userEntity = new HttpEntity<ClienteUpdateDTO>(dto,getUserHeader());
			r = restTemplate.exchange(url,HttpMethod.PUT ,userEntity, String.class);
			log.info("TEST UPDATE " + url + "UPDATE");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

		}
	  @Test
		void delete() {
			String url = "http://localhost:" + port + "/clienti/67891AB";
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY,String.class);
			log.info("TEST DELETE" + url + "DELETE");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.DELETE, adminEntity,String.class);
			log.info("TEST DELETE" + url + "DELETE");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.DELETE, userEntity,String.class);
			log.info("TEST DELETE" + url + "DELETE");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
		}
	  @Test
	    void allClientiPaged() {
			String url = "http://localhost:" + port + "/clienti" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	  @Test
	    void filterByNome() {
			String url = "http://localhost:" + port + "/clienti/filter-by-nome-contatto/mar" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	  	@Test
	    void filterByFatturato() {
			String url = "http://localhost:" + port + "/clienti/filter-by-fatturato-annuale/15.0/400000.00" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	  	@Test
	    void filterByDataInserimento() {
			String url = "http://localhost:" + port + "/clienti/filter-by-data-inserimento/12-08-2020" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
	 	@Test
	    void filterByDataUltimoContatto() {
			String url = "http://localhost:" + port + "/clienti//filter-by-data-ultimo-contatto/26-05-2022" ;
			ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
			HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
			HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
			r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
			log.info("TEST GET" + url + "GET");
			assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		}
		
}
